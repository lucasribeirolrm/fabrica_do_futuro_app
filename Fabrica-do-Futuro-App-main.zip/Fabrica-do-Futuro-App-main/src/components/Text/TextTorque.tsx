function TextTorque() {
    return (
        <div> Selecione o torque de manobra do skate - 0 mais suave e 10 mais rígido: </div>
    );
}

export default TextTorque
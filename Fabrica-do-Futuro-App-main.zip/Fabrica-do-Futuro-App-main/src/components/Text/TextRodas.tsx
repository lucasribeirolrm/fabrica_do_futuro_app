function TextRodas() {
    return (
        <div> Selecione a cor das rodas do skate para o eixo dianteiro e traseiro: </div>
    );
}

export default TextRodas
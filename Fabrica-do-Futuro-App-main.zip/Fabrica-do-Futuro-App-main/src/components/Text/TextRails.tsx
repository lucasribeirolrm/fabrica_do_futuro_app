function TextRails() {
    return (
        <div> Deseja incluir rails ao skate? </div>
    );
}

export default TextRails
function TextCaixaConectividade() {
    return (
        <div> Deseja incluir caixa de conectividade ao skate? </div>
    );
}

export default TextCaixaConectividade
function TextObservacao() {
    return (
        <div> Observação: </div>
    );
}

export default TextObservacao
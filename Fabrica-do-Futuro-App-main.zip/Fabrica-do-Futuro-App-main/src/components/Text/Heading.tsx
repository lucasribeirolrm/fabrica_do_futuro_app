import '../../style/Heading.css'

function Heading() {
    
    return <h1 id="heading"> Configurar Produto </h1>;
}

export default Heading
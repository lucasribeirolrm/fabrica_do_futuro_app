import '../../style/Buttons.css'

function ButtonsEixoDianteiro() {
    
    const handleClickGreen = () => {

    }

    const handleClickBlue = () => {

    }

    const handleClickOrange = () => {

    }

    const handleClickWhite = () => {

    }


    return (
        <div className="buttons-eixo-dianteiro">
            <button className="button green_button"></button>
            <button className="button blue_button"></button>
            <button className="button orange_button"></button>
            <button className="button white_button"></button>
        </div>
    );
}

export default ButtonsEixoDianteiro
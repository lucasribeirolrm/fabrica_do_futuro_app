import '../../style/Buttons.css'

function ButtonsEixoTraseiro() {
    
    const handleClickGreen = () => {

    }

    const handleClickBlue = () => {

    }

    const handleClickOrange = () => {

    }

    const handleClickWhite = () => {

    }


    return (
        <div className="buttons-eixo-traseiro">
            <button className="button white_button"></button>
            <button className="button orange_button"></button>
            <button className="button blue_button"></button>
            <button className="button green_button"></button>
        </div>
    );
}

export default ButtonsEixoTraseiro